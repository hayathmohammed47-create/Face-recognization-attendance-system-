# Face Recognition Attendance System (Flask)

A student-project starter with login, dashboard, webcam stream, face matching, and attendance CSV.

## Included
- Python Flask backend
- HTML/CSS pages: login, dashboard, camera, attendance report
- OpenCV webcam feed
- `face_recognition` matching against registered images
- CSV attendance storage (`data/attendance.csv`)
- Prevents duplicate attendance for the same person on the same date

## Setup (Windows)
1. Install Python 3.10 or 3.11.
2. Extract the ZIP and open the folder in VS Code.
3. Open Terminal and run:
   ```bash
   python -m venv venv
   venv\Scripts\activate
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
4. Put one clear photo per person in `known_faces`, e.g. `hayath.jpg`, `abhishek_sv.jpg`. Use JPG/JPEG/PNG and one face per image.
5. Run:
   ```bash
   python app.py
   ```
6. Open `http://127.0.0.1:5000` in your browser.

Demo login: username `admin`, password `admin123`.

## Important dependency note
`face_recognition` uses `dlib` and can be difficult to install on some Windows/Python setups. If `pip install -r requirements.txt` fails, use a compatible Python 3.10/3.11 environment and follow the package's official installation instructions, or use WSL/Linux. Do not download executables from untrusted websites. The Flask site can start without the package, but face recognition will be unavailable until it is installed.

## How to use
Login → Dashboard → Camera. Make sure the webcam is not being used by another app. Attendance appears on the Attendance page and is stored in `data/attendance.csv`. Use **Reload registered faces** after adding photos.

## Security and privacy
This is a demo, not production-ready authentication. Change the demo credentials and `app.secret_key` before any real deployment. Get appropriate permission before collecting or processing face images and attendance data.
